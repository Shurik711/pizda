﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SOCHO
{
    /// <summary>
    /// Логика взаимодействия для rate.xaml
    /// </summary>
    public partial class rate : Window
    {
        public rate()
        {
            InitializeComponent();
            string connect = "server=localhost;user=root;database=socho;password=admin;";

            MySqlConnection conn = new MySqlConnection(connect);

            DataTable table = new DataTable();

            MySqlCommand command = new MySqlCommand("SELECT id, Общий_рейтинг, Рейтинг_за_последний_год  FROM рейтинг_заведений ", conn);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            conn.Open();
            adapter.Fill(table);
            makekee.ItemsSource = table.DefaultView;
            conn.Close();
        }

        private void makekee_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void WWW_Click(object sender, RoutedEventArgs e)
        {
            Window4 window = new Window4();
            window.Show();
            Close();
        }
    }
}

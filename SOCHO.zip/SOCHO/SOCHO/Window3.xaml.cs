﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SOCHO
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        public Window3()
        {
            InitializeComponent();
            string connect = "server=localhost;user=root;database=socho;password=admin;";

            MySqlConnection conn = new MySqlConnection(connect);
            DataTable table = new DataTable();

            MySqlCommand command = new MySqlCommand("SELECT id, Name, Lastname, Email FROM socho.user", conn);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            conn.Open();
            adapter.Fill(table);
            makekee.ItemsSource = table.DefaultView;
            conn.Close();
        }

        private void dob_Click(object sender, RoutedEventArgs e)
        {
            if (id.Text == "" && Login.Text == "" && Password.Text == "" && od.Text == "")
            {
                MessageBox.Show("Пустое Поле");
            }
            if (id.Text != "" && Login.Text != "" && Password.Text != "" && od.Text != "")
            {

                InformationClass informationClass = new InformationClass();
                InformationClass.Imy = Login.Text;
                InformationClass.Sodd = Password.Text;
                StreamWriter f = new StreamWriter(InformationClass.Imy + ".txt");
                f.WriteLine(InformationClass.Sodd);
                f.Close();

                MessageBox.Show("Файл успешно создан");

                string connect = "server=localhost;user=root;database=socho;password=admin;";
                MySqlConnection conn = new MySqlConnection(connect);
                DataTable table = new DataTable();
                var addcommand = new MySqlCommand("INSERT INTO `socho`.`user` (`id` ,`Name`, `Lastname`, `Email` ) VALUES (@id, @Name, @Lastname, @Email)", conn);
                addcommand.Parameters.AddWithValue("@id", id.Text);
                addcommand.Parameters.AddWithValue("@Name", Login.Text);
                addcommand.Parameters.AddWithValue("@Lastname", Password.Text);
                addcommand.Parameters.AddWithValue("@Email", od.Text);

                conn.Open();
                addcommand.ExecuteNonQuery();

                MySqlCommand command = new MySqlCommand("SELECT id, Name, Lastname, Email FROM socho.user", conn);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);

                adapter.Fill(table);
                makekee.ItemsSource = table.DefaultView;

                conn.Close();
                id.Clear();
                Login.Clear();
                Password.Clear();
                od.Clear();
            }
        }
        public void DeleteRow(int id)
        {
            string MyConString = "server=localhost;user=root;database=socho;password=admin;";
            using (MySqlConnection con = new MySqlConnection(MyConString))
            {
                try
                {

                    string sql = "DELETE FROM `socho`.`user` WHERE (`id` = @id)";

                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(sql, con);

                    cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void Udal_Click(object sender, RoutedEventArgs e)
        {
            DataRowView drv = (DataRowView)makekee.SelectedItem;
            int id = (int)drv["id"];
            DeleteRow(id);

            string connect = "server=localhost;user=root;database=socho;password=admin;";
            MySqlConnection connn = new MySqlConnection(connect);
            DataTable table = new DataTable();
            MySqlCommand command = new MySqlCommand("SELECT id, Name, Lastname, Email FROM socho.user", connn);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            connn.Open();
            adapter.Fill(table);
            makekee.ItemsSource = table.DefaultView;

            connn.Close();
            Login.Clear();
            Password.Clear();
            od.Clear();
        }

        private void vv_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win = new MainWindow();
            win.Show();
            Close();
        }

        private void makekee_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Info_Click(object sender, RoutedEventArgs e)
        {
            user win = new user();
            win.Show();
            Close();
        }
    }
}

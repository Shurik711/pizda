﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SOCHO
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        
        private void B2_Click(object sender, RoutedEventArgs e)
        {

            MySqlConnection conn = new MySqlConnection(Class1.connPath); 
            DataTable table = new DataTable();
            MySqlCommand command = new MySqlCommand("SELECT COUNT(*) FROM autorization WHERE login ='" + tb1.Text + "' AND password ='" + tb2.Text + "' LIMIT 1", conn);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            conn.Open();
            adapter.Fill(table);
            if (table.Rows[0][0].ToString() == "1")
            {
                MySqlCommand command0 = new MySqlCommand("SELECT id FROM autorization WHERE login ='" + tb1.Text + "' AND password ='" + tb2.Text + "' LIMIT 1", conn); 
                DataTable table1 = new DataTable();
                MySqlDataAdapter adapter1 = new MySqlDataAdapter(command0);
                adapter1.Fill(table1);
                int A = Convert.ToInt32(table1.Rows[0][0]);
                MySqlCommand command2 = new MySqlCommand("SELECT Status FROM `use` WHERE autorization ='" + A + "' ", conn); 
                DataTable table2 = new DataTable();
                MySqlDataAdapter adapter2 = new MySqlDataAdapter(command2);
                adapter2.Fill(table2);

                if (Convert.ToInt32 (table2.Rows[0][0]) == 1)
                {
                    Window2 window = new Window2();
                    window.Show();
                    Close();
                }
                else if (Convert.ToInt32(table2.Rows[0][0]) == 2)
                {
                    Window3 window = new Window3();
                    window.Show();
                    Close();
                }
                else if (Convert.ToInt32(table2.Rows[0][0]) == 3)
                {
                    Window4 window = new Window4();
                    window.Show();
                    Close();
                }
                else
                    MessageBox.Show("не правильно введены данные");
                conn.Close();

            

            }
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

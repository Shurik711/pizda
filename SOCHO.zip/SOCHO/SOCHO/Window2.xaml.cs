﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SOCHO
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
            string connect = "server=localhost;user=root;database=socho;password=admin;";

            MySqlConnection conn = new MySqlConnection(connect);
            DataTable table = new DataTable();

            MySqlCommand command = new MySqlCommand("SELECT id, Название_заведения, Место_нахождения FROM socho.список_заведений", conn);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            conn.Open();
            adapter.Fill(table);
            makekee.ItemsSource = table.DefaultView;
            conn.Close();
        }

        private void dob_Click(object sender, RoutedEventArgs e)
        {
            if (id.Text == "" && Login.Text == "" && Password.Text == "")
            {
                MessageBox.Show("Пустое Поле");
            }
            if (id.Text != "" && Login.Text != "" && Password.Text != "")
            {

                InformationClass informationClass = new InformationClass();
                InformationClass.Imy = Login.Text;
                InformationClass.Sodd = Password.Text;
                StreamWriter f = new StreamWriter(InformationClass.Imy + ".txt");
                f.WriteLine(InformationClass.Sodd);
                f.Close();

                MessageBox.Show("Файл успешно создан");

                string connect = "server=localhost;user=root;database=socho;password=admin;";
                MySqlConnection conn = new MySqlConnection(connect);
                DataTable table = new DataTable();
                var addcommand = new MySqlCommand("INSERT INTO `socho`.`список_заведений` (`id` ,`Название_заведения`, `Место_нахождения`) VALUES (@id, @Связь_с_пользователем, @User_id)", conn);
                addcommand.Parameters.AddWithValue("@id", id.Text);
                addcommand.Parameters.AddWithValue("@Название_заведения", Login.Text);
                addcommand.Parameters.AddWithValue("@Место_нахождения", Password.Text);

                conn.Open();
                addcommand.ExecuteNonQuery();

                MySqlCommand command = new MySqlCommand("SELECT id, Название_заведения, Место_нахождения FROM socho.список_заведений", conn);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);

                adapter.Fill(table);
                makekee.ItemsSource = table.DefaultView;

                conn.Close();
                id.Clear();
                Login.Clear();
                Password.Clear();

            }
        }
        public void DeleteRow(int id)
        {
            string MyConString = "server=localhost;user=root;database=socho;password=admin;";
            using (MySqlConnection con = new MySqlConnection(MyConString))
            {
                try
                {

                    string sql = "DELETE FROM `socho`.`operator` WHERE (`id` = @id)";

                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(sql, con);

                    cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void Udal_Click(object sender, RoutedEventArgs e)
        {
            DataRowView drv = (DataRowView)makekee.SelectedItem;
            int id = (int)drv["id"];
            DeleteRow(id);

            string connect = "server=localhost;user=root;database=socho;password=admin;";
            MySqlConnection connn = new MySqlConnection(connect);
            DataTable table = new DataTable();
            MySqlCommand command = new MySqlCommand("SELECT id, Название_заведения, Место_нахождения FROM socho.список_заведений", connn);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            connn.Open();
            adapter.Fill(table);
            makekee.ItemsSource = table.DefaultView;

            connn.Close();
            Login.Clear();
            Password.Clear();

        }

        private void makekee_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void vv_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win = new MainWindow();
            win.Show();
            Close();
        }
    }
}

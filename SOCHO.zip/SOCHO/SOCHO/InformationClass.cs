﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOCHO
{
    class InformationClass
    {
        public static string Imy, Sodd, sa, rtuu, ky, re, na, da, ko, fi, fa, dir;
    }
}

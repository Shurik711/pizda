﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOCHO
{
    class Class1
    {
        public static string connPath = "server=localhost;user=root;database=socho;password=admin;";
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SOCHO
{
    /// <summary>
    /// Логика взаимодействия для user.xaml
    /// </summary>
    public partial class user : Window
    {
        public user()
        {
            InitializeComponent();
            string connect = "server=localhost;user=root;database=socho;password=admin;";

            MySqlConnection conn = new MySqlConnection(connect);
            DataTable table = new DataTable();

            MySqlCommand command = new MySqlCommand("SELECT id, Связь_с_пользователем, User_id FROM socho.operator", conn);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            conn.Open();
            adapter.Fill(table);
            makekee.ItemsSource = table.DefaultView;
            conn.Close();
        }

        private void dob_Click(object sender, RoutedEventArgs e)
        {
            if (id.Text == "" && Login.Text == "" && Password.Text == "") 
            {
                MessageBox.Show("Пустое Поле");
            }
            if (id.Text != "" && Login.Text != "" && Password.Text != "")
            {

                InformationClass informationClass = new InformationClass();
                InformationClass.Imy = Login.Text;
                InformationClass.Sodd = Password.Text;
                StreamWriter f = new StreamWriter(InformationClass.Imy + ".txt");
                f.WriteLine(InformationClass.Sodd);
                f.Close();

                MessageBox.Show("Файл успешно создан");

                string connect = "server=localhost;user=root;database=socho;password=admin;";
                MySqlConnection conn = new MySqlConnection(connect);
                DataTable table = new DataTable();
                var addcommand = new MySqlCommand("INSERT INTO `socho`.`operator` (`id` ,`Связь_с_пользователем`, `User_id`) VALUES (@id, @Связь_с_пользователем, @User_id)", conn);
                addcommand.Parameters.AddWithValue("@id", id.Text);
                addcommand.Parameters.AddWithValue("@Связь_с_пользователем", Login.Text);
                addcommand.Parameters.AddWithValue("@User_id", Password.Text);

                conn.Open();
                addcommand.ExecuteNonQuery();

                MySqlCommand command = new MySqlCommand("SELECT id, Связь_с_пользователем, User_id FROM socho.operator", conn);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);

                adapter.Fill(table);
                makekee.ItemsSource = table.DefaultView;

                conn.Close();
                id.Clear();
                Login.Clear();
                Password.Clear();
               
            }
        }
        public void DeleteRow(int id)
        {
            string MyConString = "server=localhost;user=root;database=socho;password=admin;";
            using (MySqlConnection con = new MySqlConnection(MyConString))
            {
                try
                {

                    string sql = "DELETE FROM `socho`.`operator` WHERE (`id` = @id)";

                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(sql, con);

                    cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void Udal_Click(object sender, RoutedEventArgs e)
        {
            DataRowView drv = (DataRowView)makekee.SelectedItem;
            int id = (int)drv["id"];
            DeleteRow(id);

            string connect = "server=localhost;user=root;database=socho;password=admin;";
            MySqlConnection connn = new MySqlConnection(connect);
            DataTable table = new DataTable();
            MySqlCommand command = new MySqlCommand("SELECT id, Связь_с_пользователем, User_id FROM socho.operator", connn);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            connn.Open();
            adapter.Fill(table);
            makekee.ItemsSource = table.DefaultView;

            connn.Close();
            Login.Clear();
            Password.Clear();
     
        }
    

        private void vv_Click(object sender, RoutedEventArgs e)
        {
            Window3 window = new Window3();
            window.Show();
            Close();
        }

        private void makekee_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
